function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  noStroke();
  fill('gray')
  arc(210, 185, 15, 20, 0, PI + PI/2);
  fill(45, 150, 132, 255);
  circle(230, 185, 45);
  fill(205, 190, 2, 200);
  circle(400, 200, 85);
  stroke(255, 255, 255, 40);
  strokeWeight(4);
  curve(10, 10, 20, 15, 350, 45, 200, 35);
  fill(255, 255, 0, 100);
  noStroke();
  triangle(350, 45, 360, 55, 370, 45);
  triangle(350, 45, 360, 35, 370, 45);
  fill(255, 30, 20, 200)
  circle(50, 230, 25);
}
