function setup() {
  createCanvas(400, 400);
}

function draw() {
  frameRate(.5);
  let circles = [100, 200, 300, mouseX];
  console.log('array size is 4, assigning y values for circles')
  let light = random(0, 3);
  background(220);
  noStroke();
  fill('black');
  rect(circles[3] - 50, 50, 100, 300);
  if(light <= 1){
  fill('red');
  circle(circles[3], circles[0], 50);
  }
  if(light <= 2 && light > 1){
  fill('yellow');
  circle(circles[3], circles[1], 50);
  }
  if(light <= 3 && light > 2){
  fill('green');
  circle(circles[3], circles[2], 50);
  }
}